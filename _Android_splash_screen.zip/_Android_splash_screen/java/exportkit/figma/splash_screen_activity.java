
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		splash_screen
	 *	@date 		Friday 17th of March 2023 07:31:40 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;

public class splash_screen_activity extends Activity {

	
	private View _bg__splash_screen;
	private ImageView b_1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);

		
		_bg__splash_screen = (View) findViewById(R.id._bg__splash_screen);
		b_1 = (ImageView) findViewById(R.id.b_1);
	
		
		//custom code goes here
	
	}
}
	
	
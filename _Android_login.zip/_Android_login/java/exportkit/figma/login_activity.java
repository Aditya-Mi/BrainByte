
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		login
	 *	@date 		Sunday 26th of March 2023 02:31:17 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.content.Intent;

public class login_activity extends Activity {

	
	private View _bg__login;
	private ImageView rectangle_4;
	private ImageView rectangle_4__stroke_;
	private ImageView log_in_;
	private ImageView mobile_number;
	private ImageView mobile_number_ek1;
	private ImageView rectangle_5;
	private ImageView rectangle_5__stroke_;
	private ImageView password;
	private ImageView all_rights_reserved;
	private ImageView forgot_password;
	private ImageView _don_t_have_an_account__sign_up;
	private ImageView enter_password;
	private ImageView vector;
	private ImageView vector_ek1;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private ImageView vector_ek4;
	private ImageView vector_ek5;
	private ImageView vector_ek6;
	private ImageView vector_ek7;
	private ImageView vector_ek8;
	private ImageView vector_ek9;
	private ImageView vector_ek10;
	private ImageView vector_ek11;
	private ImageView vector_ek12;
	private ImageView vector_ek13;
	private ImageView vector_ek14;
	private ImageView vector_ek15;
	private ImageView vector_ek16;
	private ImageView vector_ek17;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		
		_bg__login = (View) findViewById(R.id._bg__login);
		rectangle_4 = (ImageView) findViewById(R.id.rectangle_4);
		rectangle_4__stroke_ = (ImageView) findViewById(R.id.rectangle_4__stroke_);
		log_in_ = (ImageView) findViewById(R.id.log_in_);
		mobile_number = (ImageView) findViewById(R.id.mobile_number);
		mobile_number_ek1 = (ImageView) findViewById(R.id.mobile_number_ek1);
		rectangle_5 = (ImageView) findViewById(R.id.rectangle_5);
		rectangle_5__stroke_ = (ImageView) findViewById(R.id.rectangle_5__stroke_);
		password = (ImageView) findViewById(R.id.password);
		all_rights_reserved = (ImageView) findViewById(R.id.all_rights_reserved);
		forgot_password = (ImageView) findViewById(R.id.forgot_password);
		_don_t_have_an_account__sign_up = (ImageView) findViewById(R.id._don_t_have_an_account__sign_up);
		enter_password = (ImageView) findViewById(R.id.enter_password);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		vector_ek5 = (ImageView) findViewById(R.id.vector_ek5);
		vector_ek6 = (ImageView) findViewById(R.id.vector_ek6);
		vector_ek7 = (ImageView) findViewById(R.id.vector_ek7);
		vector_ek8 = (ImageView) findViewById(R.id.vector_ek8);
		vector_ek9 = (ImageView) findViewById(R.id.vector_ek9);
		vector_ek10 = (ImageView) findViewById(R.id.vector_ek10);
		vector_ek11 = (ImageView) findViewById(R.id.vector_ek11);
		vector_ek12 = (ImageView) findViewById(R.id.vector_ek12);
		vector_ek13 = (ImageView) findViewById(R.id.vector_ek13);
		vector_ek14 = (ImageView) findViewById(R.id.vector_ek14);
		vector_ek15 = (ImageView) findViewById(R.id.vector_ek15);
		vector_ek16 = (ImageView) findViewById(R.id.vector_ek16);
		vector_ek17 = (ImageView) findViewById(R.id.vector_ek17);
	
		
		_don_t_have_an_account__sign_up.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				Intent nextScreen = new Intent(getApplicationContext(), signup_2_0_activity.class);
				startActivity(nextScreen);
			
		
			}
		});
		
		
		//custom code goes here
	
	}
}
	
	
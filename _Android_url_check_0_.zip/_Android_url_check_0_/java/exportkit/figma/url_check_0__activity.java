
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		url_check_0_
	 *	@date 		Saturday 18th of March 2023 06:51:36 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;

public class url_check_0__activity extends Activity {

	
	private View _bg__url_check_0_;
	private View rectangle_6;
	private View rectangle_7;
	private TextView safe_meter;
	private TextView score_;
	private TextView paste_url_to_check;
	private TextView the_safe_meter_has_a_rating_of____for_this_app__this_app_might_have_privacy_and_security_issues__you_may_have_higher_risk;
	private View rectangle_9;
	private View rectangle_10;
	private TextView check;
	private TextView _00;
	private View rectangle_8;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.url_check_0_);

		
		_bg__url_check_0_ = (View) findViewById(R.id._bg__url_check_0_);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
		rectangle_7 = (View) findViewById(R.id.rectangle_7);
		safe_meter = (TextView) findViewById(R.id.safe_meter);
		score_ = (TextView) findViewById(R.id.score_);
		paste_url_to_check = (TextView) findViewById(R.id.paste_url_to_check);
		the_safe_meter_has_a_rating_of____for_this_app__this_app_might_have_privacy_and_security_issues__you_may_have_higher_risk = (TextView) findViewById(R.id.the_safe_meter_has_a_rating_of____for_this_app__this_app_might_have_privacy_and_security_issues__you_may_have_higher_risk);
		rectangle_9 = (View) findViewById(R.id.rectangle_9);
		rectangle_10 = (View) findViewById(R.id.rectangle_10);
		check = (TextView) findViewById(R.id.check);
		_00 = (TextView) findViewById(R.id._00);
		rectangle_8 = (View) findViewById(R.id.rectangle_8);
	
		
		//custom code goes here
	
	}
}
	
	